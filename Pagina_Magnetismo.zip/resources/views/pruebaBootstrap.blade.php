<!DOCTYPE html>
<html>
<head>
	<!--<meta charset="utf-8">-->
	<title>"Prueba bootstrap"</title>
    <base href="{{URL::asset('/')}}" target="blank" >

    <link rel="stylesheet" type="text/css" href="{{url('css/bootstrap.min.css')}}">
    <script type="text/javascript" src="{{url('js/jquery-3.2.1.min.js')}}"></script>


     <!-- Custom Theme files -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Cinema Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
    Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!--webfont-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>



</head>
<body>
 
 <h1>"Hola pinche bato!"</h1>


 <button class="alert-info" >isis</button>

 <button class="btn-primary">Hop</button>

 <a href="#" class="btn btn-primary">hola</a>



  <!-- header-section-starts -->
  <div class="full">
      <div class="menu">
        <ul>
          <li><a href="index.html"><div class="hm"><i class="home1"></i><i class="home2"></i></div></a></li>
          <li><a href="reviews.html"><div class="cat"><i class="watching"></i><i class="watching1"></i></div></a></li>
          <li><a class="active" href="contact.html"><div class="cnt"><i class="contact"></i><i class="contact1"></i></div></a></li>
        </ul>
      </div>
    <div class="main">
    <div class="contact-content">
      <div class="top-header span_top">
        <div class="logo">
          <a href="index.html"><img src="images/logo.png" alt="" /></a>
          <p>Movie Theater</p>
        </div>
        <div class="search v-search">
          <form>
            <input type="text" value="Search.." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search..';}"/>
            <input type="submit" value="">
          </form>
        </div>
        <div class="clearfix"></div>
      </div>
      <!---contact-->
<div class="main-contact">
     <h3 class="head">CONTACT</h3>
     <p>WE'RE ALWAYS HERE TO HELP YOU</p>
     <div class="contact-form">
       <form>
         <div class="col-md-6 contact-left">
            <input type="text" placeholder="Name" required/>
            <input type="text" placeholder="E-mail" required/>
            <input type="text" placeholder="Phone" required/>
          </div>
          <div class="col-md-6 contact-right">
           <textarea placeholder="Message"></textarea>
           <input type="submit" value="SEND"/>
         </div>
         <div class="clearfix"></div>
       </form>
       </div>
</div>
  <div class="footer">
    <h6>Disclaimer : </h6>
    <p class="claim">This is a freebies and not an official website, I have no intention of disclose any movie, brand, news.My goal here is to train or excercise my skill and share this freebies.</p>
    <a href="example@mail.com">example@mail.com</a>
    <div class="copyright">
      <p> Template by  <a href="http://w3layouts.com">  W3layouts</a></p>
    </div>
  </div>  
  </div>
  <div class="clearfix"></div>
  </div>
 <script type="text/javascript" src="{{url('js/popper.min.js')}}"></script>
  <script type="text/javascript" src="{{url('js/bootstrap.min.js')}}"></script>
</body>
</html>